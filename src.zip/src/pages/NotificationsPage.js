function NotificationsPage(){

}

export default NotificationsPage;