function SettingsPage(){

}

export default SettingsPage;