function SigninPage(){
    return(
        <div>
            SigninPage
        </div>
    );
}

export default SigninPage;