function MoneyPage(){

}

export default MoneyPage;